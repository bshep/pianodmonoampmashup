// This File was Auto Created By Amp Config 7/13/2015 9:27:01 AM
var webip = 'http://127.0.0.1:50230/';
var usewebapi = false;
// Do not Modify, Your Changes will be lost
